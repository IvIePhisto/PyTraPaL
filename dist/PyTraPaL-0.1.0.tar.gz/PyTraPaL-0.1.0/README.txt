PyTraPaL — Python Traversal Path Language
=========================================

This project implements a path language to traverse structures of objects for
Python 2 and 3. It is developed as part of the diploma thesis of Michael Pohl
"Architektur und Implementierung des Objektmodells für ein Web Application
Framework" (Rheinische Friedrich-Wilhelms Universität Bonn, 2013-2014).
